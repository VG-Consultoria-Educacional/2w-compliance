ASSET_PREFIX = "";
SCRIPT_PREFIX = "";
SCENE_PATH = "1204697.json";
CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "default"
};
SCRIPTS = [ 52807835, 52807585, 52807777, 52807584, 52807582, 52807583, 52807699, 52807598, 52807600, 52807698, 52807700, 52807702, 52807774, 52807779, 52807780, 52807782, 52807783, 52807784, 52807787, 52807789, 52807778, 52807597, 52807805, 52807807, 52807833, 52807836 ];
CONFIG_FILENAME = "config.json";
INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
PRELOAD_MODULES = [
];
