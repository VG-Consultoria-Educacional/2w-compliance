var Testes = pc.createScript('testes');

// initialize code called once per entity
Testes.prototype.initialize = function() {
    //alert(this.name + ': ' + this.entity.getPosition());
};

// update code called every frame
Testes.prototype.update = function(dt) {
    
};

// swap method called for script hot-reloading
// inherit your script state here
// Testes.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// [0.6844531297683716, 0.31434166431427, 3.552713678800501e-13]