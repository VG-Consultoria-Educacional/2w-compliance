function dStr(value){
   return value;
   
}