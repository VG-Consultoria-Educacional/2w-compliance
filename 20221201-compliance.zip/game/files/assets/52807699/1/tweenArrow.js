var TweenArrow = pc.createScript('tweenArrow');

// initialize code called once per entity
TweenArrow.prototype.initialize = function() {
   

};