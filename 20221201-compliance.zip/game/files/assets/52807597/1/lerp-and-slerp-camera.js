var LerpAndSlerpCamera = pc.createScript('lerpAndSlerpCamera');

// initialize code called once per entity
LerpAndSlerpCamera.prototype.initialize = function() {
    
};

// update code called every frame
LerpAndSlerpCamera.prototype.update = function(dt) {
    
};

// swap method called for script hot-reloading
// inherit your script state here
// LerpAndSlerpCamera.prototype.swap = function(old) { };

// to learn more about script anatomy, please read:
// http://developer.playcanvas.com/en/user-manual/scripting/